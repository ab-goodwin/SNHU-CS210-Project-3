
// Brady Goodwin
// CS210 Project 3
// 10/15/2023

#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;

class GroceryFrequency {
public:
    // reads input file and calculates the frequency of items
    void processInputFile(string filename) {
        ifstream input(filename);
        if (input.fail()) {
            cout << "Could not open filename:" << filename << endl;
            return;
        }
        string item;
        while (input >> item) {
            freqData[item]++;
        }
        input.close();
    }

    // prints numerical frequency of one item
    int getItemFrequency(string item) {
        return freqData[item];
    }

    // prints the list of all items and frequencies
    void printFrequencyList() {
        for (auto it = freqData.begin(); it != freqData.end(); ++it) {
            cout << it->first << ": " << it->second << endl;
        }
    }

    // prints the histogram chart of item frequencies
    void printHistogram() {
        for (auto it = freqData.begin(); it != freqData.end(); ++it) {
            cout << it->first << " ";
            for (int i = 0; i < it->second; i++) {
                cout << "*";
            }
            cout << endl;
        }
    }

    // frequency.dat backup file
    void backupFrequencyData(string filename) {
        ofstream output(filename);
        if (output.fail()) {
            cout << "Error: Could not open file " << filename << endl;
            return;
        }
        for (auto it = freqData.begin(); it != freqData.end(); ++it) {
            output << it->first << ": " << it->second << endl;
        }
        output.close();
    }

private:
    map<string, int> freqData;
};

int main() {
    GroceryFrequency grocery;

    // process input file
    grocery.processInputFile("CS210_Project_Three_Input_File.txt");

    // menu loop
    bool running = true;
    while (running) {
        cout << endl;
        cout << "Pick an option:" << endl;
        cout << "1) Look up an specific item / frequency" << endl;
        cout << "2) Print a numerical list of all items / frequencies" << endl;
        cout << "3) Print a histogram of all items / frequencies" << endl;
        cout << "4) Exit the program" << endl;

        // Get user input
        int choice;
        cout << "Enter selection: ";
        cin >> choice;
        cout << endl;

        // user input selection
        switch (choice) {
        case 1: {
            string item;
            cout << "Lookup which item?:  ";
            cin >> item;
            cout << endl;

            int freq = grocery.getItemFrequency(item);
            cout << item << ": " << freq << endl;
            break;
        }
        case 2: {
            grocery.printFrequencyList();
            break;
        }
        case 3: {
            grocery.printHistogram();
            break;
        }
        case 4: {
            grocery.backupFrequencyData("frequency.dat");
            exit(0);
        }
        default: { // validate user input
            cout << "Invalid selection: Please pick a valid option." << endl;
            break;
        }
        }
    }
    return 0;
}